// pry_ex/lib/vistas/pagina_inicio_ventas.dart
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:pry_ex/proveedores/proveedor_tema.dart';
import 'package:pry_ex/proveedores/proveedor_ventas.dart';
import 'package:pry_ex/modelos/modelo_venta.dart';
import 'package:intl/intl.dart'; // Para formatear moneda y fechas

class PaginaInicioVentas extends StatefulWidget {
  const PaginaInicioVentas({super.key});

  @override
  State<PaginaInicioVentas> createState() => _PaginaInicioVentasState();
}

class _PaginaInicioVentasState extends State<PaginaInicioVentas> {
  final _controladorMonto = TextEditingController();
  CategoriaVenta _categoriaSeleccionada = CategoriaVenta.otros; // Valor inicial

  void _mostrarDialogoAgregarVenta(BuildContext context) {
    _controladorMonto.clear();
    _categoriaSeleccionada = CategoriaVenta.otros; // Resetear a la categoría por defecto

    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext ctxDialogo) {
        // Usar StatefulBuilder para que el DropdownButton se actualice dentro del diálogo
        return StatefulBuilder(
          builder: (BuildContext context, StateSetter setStateDialogo) {
            return AlertDialog(
              title: const Text('Registrar Nueva Venta'),
              content: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: <Widget>[
                    TextField(
                      controller: _controladorMonto,
                      decoration: const InputDecoration(
                        labelText: 'Monto de la Venta',
                        prefixIcon: Icon(Icons.attach_money),
                      ),
                      keyboardType: const TextInputType.numberWithOptions(decimal: true),
                      autofocus: true,
                    ),
                    const SizedBox(height: 20),
                    DropdownButtonFormField<CategoriaVenta>(
                      decoration: const InputDecoration(
                        labelText: 'Categoría',
                        border: OutlineInputBorder(),
                        prefixIcon: Icon(Icons.category),
                      ),
                      value: _categoriaSeleccionada,
                      items: CategoriaVenta.values.map((CategoriaVenta categoria) {
                        return DropdownMenuItem<CategoriaVenta>(
                          value: categoria,
                          child: Text(obtenerNombreCategoria(categoria)),
                        );
                      }).toList(),
                      onChanged: (CategoriaVenta? nuevoValor) {
                        if (nuevoValor != null) {
                          setStateDialogo(() { // Actualiza el estado del diálogo
                            _categoriaSeleccionada = nuevoValor;
                          });
                        }
                      },
                    ),
                  ],
                ),
              ),
              actions: <Widget>[
                TextButton(
                  child: const Text('Cancelar'),
                  onPressed: () {
                    Navigator.of(ctxDialogo).pop();
                  },
                ),
                ElevatedButton(
                  child: const Text('Guardar Venta'),
                  onPressed: () {
                    final proveedorVentas = Provider.of<ProveedorVentas>(context, listen: false);
                    final monto = double.tryParse(_controladorMonto.text.replaceAll(',', '.')); // Reemplazar coma por punto si es necesario

                    if (monto == null || monto <= 0) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(
                            content: Text('Por favor, ingresa un monto válido y mayor a cero.'),
                            backgroundColor: Colors.redAccent),
                      );
                      return;
                    }
                    proveedorVentas.agregarNuevaVenta(monto, _categoriaSeleccionada);
                    Navigator.of(ctxDialogo).pop(); // Cierra el diálogo
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                          content: Text('Venta de ${obtenerNombreCategoria(_categoriaSeleccionada)} registrada con éxito.'),
                          backgroundColor: Colors.green[700]),
                    );
                  },
                ),
              ],
            );
          },
        );
      },
    );
  }

  @override
  void dispose() {
    _controladorMonto.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final proveedorTema = Provider.of<ProveedorTema>(context);
    final proveedorVentas = Provider.of<ProveedorVentas>(context);
    // Formato de moneda local (ej. Ecuador usa USD, pero podrías adaptarlo)
    final formatoMoneda = NumberFormat.currency(locale: 'es_EC', symbol: '\$');
    final formatoFechaHora = DateFormat('dd/MM/yyyy HH:mm', 'es_ES');

    final coloresCategoriasActual = proveedorTema.esModoOscuro ? coloresCategoriaOscuro : coloresCategoriaClaro;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Ventas Tiki Taka'),
        actions: [
          IconButton(
            icon: Icon(proveedorTema.esModoOscuro ? Icons.light_mode : Icons.dark_mode),
            tooltip: proveedorTema.esModoOscuro ? 'Activar Tema Claro' : 'Activar Tema Oscuro',
            onPressed: () {
              proveedorTema.alternarTema();
            },
          ),
        ],
      ),
      body: Column(
        children: [
          _ConstruirPanelAnalisis(proveedorVentas: proveedorVentas, formatoMoneda: formatoMoneda),
          Expanded(
            child: proveedorVentas.ventasRegistradas.isEmpty
                ? Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.point_of_sale_outlined, size: 80, color: Theme.of(context).disabledColor),
                  const SizedBox(height: 16),
                  const Text('No hay ventas registradas aún.', style: TextStyle(fontSize: 18)),
                  const SizedBox(height: 8),
                  const Text('Presiona el botón (+) para agregar una nueva venta.'),
                ],
              ),
            )
                : ListView.builder(
              padding: const EdgeInsets.all(8.0),
              itemCount: proveedorVentas.ventasRegistradas.length,
              itemBuilder: (ctx, indice) {
                final venta = proveedorVentas.ventasRegistradas[indice];
                final colorCategoria = coloresCategoriasActual[venta.categoria] ?? Colors.grey;
                return Card(
                  elevation: 2,
                  margin: const EdgeInsets.symmetric(vertical: 6.0),
                  shape: RoundedRectangleBorder(
                    side: BorderSide(color: colorCategoria.withOpacity(0.7), width: 1.5),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: ListTile(
                    leading: CircleAvatar(
                      backgroundColor: colorCategoria,
                      foregroundColor: colorCategoria.computeLuminance() > 0.5 ? Colors.black : Colors.white,
                      child: _ObtenerIconoParaCategoria(venta.categoria),
                    ),
                    title: Text(
                      'Monto: ${formatoMoneda.format(venta.monto)}',
                      style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                    ),
                    subtitle: Text(
                        'Categoría: ${obtenerNombreCategoria(venta.categoria)}\nFecha: ${formatoFechaHora.format(venta.fecha)}'),
                    trailing: Text('#${venta.id.substring(0, 6)}...', style: TextStyle(fontSize: 12, color: Theme.of(context).hintColor)),
                  ),
                );
              },
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _mostrarDialogoAgregarVenta(context),
        icon: const Icon(Icons.add_shopping_cart_outlined),
        label: const Text('Nueva Venta'),
        tooltip: 'Registrar una nueva venta',
      ),
    );
  }
}

class _ConstruirPanelAnalisis extends StatelessWidget {
  const _ConstruirPanelAnalisis({
    required this.proveedorVentas,
    required this.formatoMoneda,
  });

  final ProveedorVentas proveedorVentas;
  final NumberFormat formatoMoneda;

  @override
  Widget build(BuildContext context) {
    final tema = Theme.of(context);
    final totalesPorCategoria = proveedorVentas.montoTotalPorCategoria;

    return Card(
      elevation: 3,
      margin: const EdgeInsets.all(12.0),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text('Análisis de Ventas', style: tema.textTheme.titleLarge?.copyWith(color: tema.colorScheme.primary)),
            const SizedBox(height: 12),
            _FilaAnalisis(etiqueta: 'Ventas > ${formatoMoneda.format(1000)}:', valor: '${proveedorVentas.cantidadVentasMayoresA1000}'),
            _FilaAnalisis(etiqueta: 'Ventas > ${formatoMoneda.format(500)} y <= ${formatoMoneda.format(1000)}:', valor: '${proveedorVentas.cantidadVentasEntre500Y1000}'),
            _FilaAnalisis(etiqueta: 'Ventas <= ${formatoMoneda.format(500)}:', valor: '${proveedorVentas.cantidadVentasMenoresOIgualesA500}'),
            const Divider(height: 24, thickness: 1),
            _FilaAnalisis(
              etiqueta: 'Monto Total Vendido Global:',
              valor: formatoMoneda.format(proveedorVentas.montoTotalVendidoGlobal),
              estiloValor: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
            ),
            const SizedBox(height: 12),
            Text('Detalle por Categoría:', style: tema.textTheme.titleMedium),
            const SizedBox(height: 8),
            if (totalesPorCategoria.entries.where((e) => e.value > 0).isEmpty)
              Padding(
                padding: const EdgeInsets.only(left: 8.0, top: 4.0),
                child: Text('Sin ventas registradas en categorías específicas.', style: TextStyle(fontStyle: FontStyle.italic, color: tema.hintColor)),
              )
            else
              Column(
                children: totalesPorCategoria.entries
                    .where((entry) => entry.value > 0) // Solo mostrar categorías con ventas
                    .map((entry) => _FilaAnalisis(
                  etiqueta: '  • ${obtenerNombreCategoria(entry.key)}:',
                  valor: formatoMoneda.format(entry.value),
                ))
                    .toList(),
              ),
          ],
        ),
      ),
    );
  }
}

class _FilaAnalisis extends StatelessWidget {
  final String etiqueta;
  final String valor;
  final TextStyle? estiloEtiqueta;
  final TextStyle? estiloValor;

  const _FilaAnalisis({
    required this.etiqueta,
    required this.valor,
    this.estiloEtiqueta,
    this.estiloValor,
  });

  @override
  Widget build(BuildContext context) {
    final tema = Theme.of(context);
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(etiqueta, style: estiloEtiqueta ?? tema.textTheme.bodyMedium),
          Text(valor, style: estiloValor ?? tema.textTheme.bodyMedium?.copyWith(fontWeight: FontWeight.w600)),
        ],
      ),
    );
  }
}

class _ObtenerIconoParaCategoria extends StatelessWidget {
  final CategoriaVenta categoria;
  const _ObtenerIconoParaCategoria(this.categoria);

  @override
  Widget build(BuildContext context) {
    switch (categoria) {
      case CategoriaVenta.electronicos:
        return const Icon(Icons.devices_other_outlined);
      case CategoriaVenta.ropa:
        return const Icon(Icons.checkroom_outlined);
      case CategoriaVenta.alimentos:
        return const Icon(Icons.restaurant_menu_outlined);
      case CategoriaVenta.hogar:
        return const Icon(Icons.home_work_outlined);
      case CategoriaVenta.otros:
        return const Icon(Icons.category_outlined);
      default:
        return const Icon(Icons.sell_outlined);
    }
  }
}
