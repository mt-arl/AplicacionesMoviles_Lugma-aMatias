// pry_ex/lib/modelos/modelo_venta.dart
import 'package:flutter/material.dart';

enum CategoriaVenta {
  electronicos,
  ropa,
  alimentos,
  hogar,
  otros,
}

String obtenerNombreCategoria(CategoriaVenta categoria) {
  switch (categoria) {
    case CategoriaVenta.electronicos:
      return 'Electrónicos';
    case CategoriaVenta.ropa:
      return 'Ropa';
    case CategoriaVenta.alimentos:
      return 'Alimentos';
    case CategoriaVenta.hogar:
      return 'Hogar';
    case CategoriaVenta.otros:
      return 'Otros';
    default:
      return 'Desconocida';
  }
}

class ModeloVenta {
  final String id;
  final double monto;
  final CategoriaVenta categoria;
  final DateTime fecha;

  ModeloVenta({
    required this.id,
    required this.monto,
    required this.categoria,
    required this.fecha,
  });
}

Map<CategoriaVenta, Color> coloresCategoriaClaro = {
  CategoriaVenta.electronicos: Colors.blue.shade600,
  CategoriaVenta.ropa: Colors.pink.shade400,
  CategoriaVenta.alimentos: Colors.green.shade600,
  CategoriaVenta.hogar: Colors.orange.shade700,
  CategoriaVenta.otros: Colors.grey.shade600,
};

Map<CategoriaVenta, Color> coloresCategoriaOscuro = {
  CategoriaVenta.electronicos: Colors.blueAccent.shade100,
  CategoriaVenta.ropa: Colors.pinkAccent.shade100,
  CategoriaVenta.alimentos: Colors.lightGreenAccent.shade200,
  CategoriaVenta.hogar: Colors.orangeAccent.shade100,
  CategoriaVenta.otros: Colors.blueGrey.shade300,
};
