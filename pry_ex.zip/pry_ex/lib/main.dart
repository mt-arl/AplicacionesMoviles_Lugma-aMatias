// pry_ex/lib/main.dart
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:intl/date_symbol_data_local.dart'; // Para inicializar localización de fechas
import 'package:pry_ex/proveedores/proveedor_tema.dart';
import 'package:pry_ex/proveedores/proveedor_ventas.dart';
import 'package:pry_ex/vistas/pagina_inicio_ventas.dart';

void main() async {

  WidgetsFlutterBinding.ensureInitialized();

  await initializeDateFormatting('es_ES', null);

  runApp(const MyAppVentasTikiTaka());
}

class MyAppVentasTikiTaka extends StatelessWidget {
  const MyAppVentasTikiTaka({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => ProveedorTema()),
        ChangeNotifierProvider(create: (_) => ProveedorVentas()),
      ],
      child: Consumer<ProveedorTema>(
        builder: (context, proveedorTema, child) {
          return MaterialApp(
            title: 'Ventas Tiki Taka',
            theme: proveedorTema.temaActual, // Usa el tema claro por defecto
            // darkTheme: proveedorTema.temaOscuroAplicacion, // Opcional: definir tema oscuro explícitamente aquí
            // themeMode: proveedorTema.esModoOscuro ? ThemeMode.dark : ThemeMode.light, // Opcional: si quieres controlarlo así
            home: const PaginaInicioVentas(), // La página de inicio de la app
            debugShowCheckedModeBanner: false,
            // Definir localizaciones soportadas si se usa internacionalización más a fondo
            // supportedLocales: const [
            //   Locale('es', 'ES'),
            //   // Locale('en', 'US'),
            // ],
            // localizationsDelegates: const [
            //   GlobalMaterialLocalizations.delegate,
            //   GlobalWidgetsLocalizations.delegate,
            //   GlobalCupertinoLocalizations.delegate,
            // ],
          );
        },
      ),
    );
  }
}
