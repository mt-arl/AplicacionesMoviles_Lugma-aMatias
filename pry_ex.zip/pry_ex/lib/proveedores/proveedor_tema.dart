// pry_ex/lib/proveedores/proveedor_tema.dart
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class ProveedorTema with ChangeNotifier {
  static const String _clavePreferenciaTema = 'preferencia_tema_pry_ex'; // Clave única para este app
  bool _esModoOscuro = false;

  ProveedorTema() {
    _cargarPreferenciaTema();
  }

  bool get esModoOscuro => _esModoOscuro;

  ThemeData get temaActual => _esModoOscuro ? temaOscuroAplicacion : temaClaroAplicacion;

  // tema cLaro
  static final ThemeData temaClaroAplicacion = ThemeData(
    brightness: Brightness.light,
    primarySwatch: Colors.indigo,
    primaryColor: Colors.indigo[700],
    scaffoldBackgroundColor: Colors.grey[50],
    colorScheme: ColorScheme.light(
      primary: Colors.indigo[700]!,
      secondary: Colors.pinkAccent,
      surface: Colors.white,
      background: Colors.grey[50]!,
      error: Colors.red.shade700,
      onPrimary: Colors.white,
      onSecondary: Colors.white,
      onSurface: Colors.black87,
      onBackground: Colors.black87,
      onError: Colors.white,
    ),
    appBarTheme: AppBarTheme(
      color: Colors.indigo[700],
      elevation: 2,
      iconTheme: const IconThemeData(color: Colors.white),
      titleTextStyle: const TextStyle(
          color: Colors.white, fontSize: 20, fontWeight: FontWeight.w500),
    ),
    floatingActionButtonTheme: FloatingActionButtonThemeData(
      backgroundColor: Colors.pinkAccent,
      foregroundColor: Colors.white,
    ),
    elevatedButtonTheme: ElevatedButtonThemeData(
      style: ElevatedButton.styleFrom(
        backgroundColor: Colors.indigo[600],
        foregroundColor: Colors.white,
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
        textStyle: const TextStyle(fontSize: 16, fontWeight: FontWeight.w500),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
      ),
    ),
    inputDecorationTheme: InputDecorationTheme(
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(8),
        borderSide: BorderSide(color: Colors.grey[400]!),
      ),
      focusedBorder: OutlineInputBorder(
        borderSide: BorderSide(color: Colors.indigo[700]!, width: 2),
        borderRadius: BorderRadius.circular(8),
      ),
      labelStyle: TextStyle(color: Colors.indigo[700]),
    ),
    cardTheme: CardTheme(
      elevation: 1,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      margin: const EdgeInsets.symmetric(vertical: 6, horizontal: 8),
    ),
    textTheme: const TextTheme(
      titleLarge: TextStyle(fontSize: 22.0, fontWeight: FontWeight.bold, color: Colors.black87),
      titleMedium: TextStyle(fontSize: 18.0, fontWeight: FontWeight.w600, color: Colors.black87),
      bodyMedium: TextStyle(fontSize: 16.0, color: Colors.black54),
    ),
    iconTheme: IconThemeData(color: Colors.indigo[700]),
  );

  //  Tema Oscuro -
  static final ThemeData temaOscuroAplicacion = ThemeData(
    brightness: Brightness.dark,
    primarySwatch: Colors.blueGrey,
    primaryColor: Colors.blueGrey[700],
    scaffoldBackgroundColor: const Color(0xFF121212),
    colorScheme: ColorScheme.dark(
      primary: Colors.tealAccent[200]!,
      secondary: Colors.pinkAccent[100]!, // Color de acento para modo oscuro
      surface: const Color(0xFF1E1E1E), // Superficies de componentes como cards
      background: const Color(0xFF121212),
      error: Colors.redAccent.shade100,
      onPrimary: Colors.black, // Texto/iconos sobre el color primario
      onSecondary: Colors.black, // Texto/iconos sobre el color secundario
      onSurface: Colors.white,   // Texto/iconos sobre superficies
      onBackground: Colors.white, // Texto/iconos sobre el fondo general
      onError: Colors.black,
    ),
    appBarTheme: AppBarTheme(
      color: Colors.grey[850],
      elevation: 2,
      iconTheme: IconThemeData(color: Colors.tealAccent[200]),
      titleTextStyle: TextStyle(
          color: Colors.tealAccent[200], fontSize: 20, fontWeight: FontWeight.w500),
    ),
    floatingActionButtonTheme: FloatingActionButtonThemeData(
      backgroundColor: Colors.pinkAccent[100],
      foregroundColor: Colors.black,
    ),
    elevatedButtonTheme: ElevatedButtonThemeData(
      style: ElevatedButton.styleFrom(
        backgroundColor: Colors.tealAccent[200],
        foregroundColor: Colors.black,
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
        textStyle: const TextStyle(fontSize: 16, fontWeight: FontWeight.w500),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
      ),
    ),
    inputDecorationTheme: InputDecorationTheme(
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(8),
        borderSide: BorderSide(color: Colors.grey[700]!),
      ),
      focusedBorder: OutlineInputBorder(
        borderSide: BorderSide(color: Colors.tealAccent[200]!, width: 2),
        borderRadius: BorderRadius.circular(8),
      ),
      labelStyle: TextStyle(color: Colors.tealAccent[200]),
      hintStyle: TextStyle(color: Colors.grey[500]),
    ),
    cardTheme: CardTheme(
      color: const Color(0xFF1E1E1E),
      elevation: 1,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      margin: const EdgeInsets.symmetric(vertical: 6, horizontal: 8),
    ),
    textTheme: TextTheme(
      titleLarge: TextStyle(fontSize: 22.0, fontWeight: FontWeight.bold, color: Colors.white.withOpacity(0.87)),
      titleMedium: TextStyle(fontSize: 18.0, fontWeight: FontWeight.w600, color: Colors.white.withOpacity(0.87)),
      bodyMedium: TextStyle(fontSize: 16.0, color: Colors.white.withOpacity(0.70)),
    ),
    iconTheme: IconThemeData(color: Colors.tealAccent[200]),
  );

  void alternarTema() async {
    _esModoOscuro = !_esModoOscuro;
    await _guardarPreferenciaTema();
    notifyListeners();
  }

  Future<void> _cargarPreferenciaTema() async {
    final prefs = await SharedPreferences.getInstance();
    _esModoOscuro = prefs.getBool(_clavePreferenciaTema) ?? false;
    notifyListeners();
  }

  Future<void> _guardarPreferenciaTema() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_clavePreferenciaTema, _esModoOscuro);
  }
}
