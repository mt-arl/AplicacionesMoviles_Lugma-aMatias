// pry_ex/lib/proveedores/proveedor_ventas.dart
import 'package:flutter/foundation.dart';
import 'package:pry_ex/modelos/modelo_venta.dart';
import 'package:uuid/uuid.dart';

class ProveedorVentas with ChangeNotifier {
  final List<ModeloVenta> _listaVentas = [];
  final Uuid _uuid = const Uuid();

  List<ModeloVenta> get ventasRegistradas => [..._listaVentas];

  // nuevas ventas
  void agregarNuevaVenta(double monto, CategoriaVenta categoria) {
    if (monto <= 0) return;

    final nuevaVenta = ModeloVenta(
      id: _uuid.v4(),
      monto: monto,
      categoria: categoria,
      fecha: DateTime.now(),
    );
    _listaVentas.add(nuevaVenta);
    notifyListeners();
  }

  // algoritmo
  int get cantidadVentasMayoresA1000 {
    // Esto es equivalente a:
    // int contador = 0;
    // para cada venta en _listaVentas:
    //   si venta.monto > 1000:
    //     contador++;
    // retornar contador;
    return _listaVentas.where((venta) => venta.monto > 1000).length;
  }

  int get cantidadVentasEntre500Y1000 {
    return _listaVentas.where((venta) => venta.monto > 500 && venta.monto <= 1000).length;
  }

  int get cantidadVentasMenoresOIgualesA500 {
    // Se consideran solo montos positivos para este contador específico.
    return _listaVentas.where((venta) => venta.monto <= 500 && venta.monto > 0).length;
  }

  double get montoTotalVendidoGlobal {
    if (_listaVentas.isEmpty) return 0.0;
    // Esto es equivalente a:
    // double total = 0.0;
    // para cada venta en _listaVentas:
    //   si venta.monto > 0: // Considerar solo montos positivos
    //     total += venta.monto;
    // retornar total;
    return _listaVentas
        .where((venta) => venta.monto > 0) // Sumar solo montos positivos
        .fold(0.0, (sumaParcial, venta) => sumaParcial + venta.monto);
  }

  Map<CategoriaVenta, double> get montoTotalPorCategoria {
    final Map<CategoriaVenta, double> totalesPorCategoria = {};
    // Inicializar todas las categorías posibles a 0.0
    for (var categoriaEnum in CategoriaVenta.values) {
      totalesPorCategoria[categoriaEnum] = 0.0;
    }

    // para cada venta en _listaVentas:
    //   si venta.monto > 0: // Considerar solo montos positivos
    //     totalesPorCategoria[venta.categoria] += venta.monto;
    for (var venta in _listaVentas) {
      if (venta.monto > 0) { // Sumar solo montos positivos
        totalesPorCategoria[venta.categoria] = (totalesPorCategoria[venta.categoria] ?? 0.0) + venta.monto;
      }
    }
    return totalesPorCategoria;
  }
  // --- FIN DE LA LÓGICA DEL ALGORITMO DE ANÁLISIS DE VENTAS ---

  // Método para limpiar todas las ventas (opcional, para pruebas)
  void limpiarTodasLasVentas() {
    _listaVentas.clear();
    notifyListeners();
  }
}
